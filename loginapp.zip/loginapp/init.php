<?php

$host = "localhost";
$user_name = "root";
$user_password = "";
$db_name = "beap";

$con = mysqli_connect($host, $user_name, $user_password, $db_name);


?>