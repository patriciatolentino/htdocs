<?php

require "init.php";

$user_name = $_POST["username"];
$user_password = $_POST["password"];

$sql = "select name from users_info where 
username= '$user_name' and password='$user_password'";

$result = mysqli_query($con, $sql);
$count = mysqli_num_rows($result);

if($count > 0)
{ 
$row = mysqli_fetch_assoc($result);
$name = $row['name'];
$status = "ok";
echo json_encode(array("response"=>$status, "name"=>$name));

}
else 
{
$status = "failed";
echo json_encode(array("response"=>$status));
}

mysqli_close ($con);

?> 