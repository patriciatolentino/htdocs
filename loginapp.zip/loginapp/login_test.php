<html>
<title>LOGIN TESTing testing lang</title>
<body>
<form method="get" action="login.php">

<table>
<tr>
<td>
Username: 
</td>
<td>
<input type="text" name="username"/>
</td>
</tr>

<tr>
<td>
Password: 
<td>
<input type="password" name="password"/>
</td>
</tr>

<tr>
<td>
<input type="submit" value="login"/>
</td>
</tr>
</table>
</form>
</body>
</html>
